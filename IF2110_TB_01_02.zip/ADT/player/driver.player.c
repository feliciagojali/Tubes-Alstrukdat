#include "../player/player.h"

int main(){

    Player X = initPlayer(1);
    Player Y = initPlayer(2);

    return 0;
}