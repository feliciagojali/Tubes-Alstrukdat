#!/bin/bash
gcc main.c ADT/stackt/stackt.c ADT/graph/graph.c ADT/pcolor/pcolor.c ADT/mesinkar/mesinkar.c ADT/mesinkata/mesinkata.c ADT/point/point.c ADT/bangunan/bangunan.c ADT/matriks/matriks.c ADT/arraydin/arraydin.c ADT/listlinier/listlinier.c ADT/player/player.c ADT/queue/queue.c ADT/mesinkar/mesinkark.c ADT/mesinkata/mesinkatak.c -o main
read -p "Press [Enter] key to quit..."