#include "../point/point.h"

int main(){

    Point T = MakePOINT(3, 7);
    TulisPOINT(T);
    return 0;
}