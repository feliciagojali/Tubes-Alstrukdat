#include "../pcolor/pcolor.h"

int main(){
    print_green('G');
    return 0;
}