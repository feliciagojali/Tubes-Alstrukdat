#include "../mesinkata/mesinkatak.h"

int main(){
    STARTKATAK();
    KataK x;
    InputK(&x);
    PrintKataK(x);
    return 0;
}