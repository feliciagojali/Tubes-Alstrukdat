#include "../matriks/matriks.h"

int main(){
    MATRIKS M;
    MakeMATRIKS(5, 7, &M);
    TulisMATRIKS(M);

    return 0;
}