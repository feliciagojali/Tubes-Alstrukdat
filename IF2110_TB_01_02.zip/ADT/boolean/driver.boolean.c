#include <stdio.h>
#include "../boolean/boolean.h"

int main(){
    
    boolean x = true;

    if(x){
        printf("hello.\n");
    }

    return 0;
}