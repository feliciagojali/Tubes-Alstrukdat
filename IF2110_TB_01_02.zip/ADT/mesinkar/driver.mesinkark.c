#include "../mesinkar/mesinkark.h"

int main(){
    STARTK();

    printf("%c", CCK);

    return 0;
}