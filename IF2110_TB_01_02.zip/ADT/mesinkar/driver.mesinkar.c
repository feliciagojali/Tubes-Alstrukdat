#include "../mesinkar/mesinkar.h"

int main(){
    START(2);

    printf("%c", CC);

    return 0;
}