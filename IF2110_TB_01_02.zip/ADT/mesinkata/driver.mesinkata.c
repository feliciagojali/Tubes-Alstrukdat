#include "../mesinkata/mesinkata.h"

int main(){
    STARTKATA(2, '#');
    Kata x;
    Input(&x);
    PrintKata(x);
    return 0;
}