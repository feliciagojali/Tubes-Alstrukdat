# AVATAR WORLD WAR : Battle of Two Major Kingdoms in Nusantara
Program ini dibuat untuk menyelesaikan Tugas Besar mata kuliah Algoritma & Struktur Data (IF2110)

Kelompok 01 K-02
- Jun Ho Choi Hedyatmo (13518044)
- Michelle Theresia    (13518050)
- Syarifuddin F A      (13518095)
- Felicia Gojali       (13518101)
- Yasyfiana Fariha P   (13518143)
- Judhistira Natha J   (13515119)



## Deskripsi Program
Program ini dibuat sesuai dengan spesifikasi dari tugas besar Algoritma & Struktur Data

## Menjalankan Program
Untuk menjalankan program ini dapat menggunakan command prompt di windows, namun agar mudah kami menambahkan shell script (test.sh) untuk mengkompilasi
program menjadi sebuah file .exe, lalu file .exe tersebut dapat dijalankan untuk memulai game.

```
D:\Tempat menaruh Tubes > test.sh
\\ ini akan menjalankan shell script, perlu perhatian bahwa diperlukan bash untuk menjalankan shell script ini (gitbash misalnya)
\\ setelah dijalankan akan membuat file main.exe, untuk menjalankan tinggal di buka seperti biasa saja
```
