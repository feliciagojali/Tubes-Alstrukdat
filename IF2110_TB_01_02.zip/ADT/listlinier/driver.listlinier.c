#include "../listlinier/listlinier.h"

int main(){
    List L;
    CreateEmptyList(&L);
    InsVLast(&L, 3);
    InsVLast(&L, 4);
    InsVLast(&L, 7);
    InsVLast(&L, 10);


    return 0;
}